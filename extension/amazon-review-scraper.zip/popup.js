function platformFromUrl(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    if (/amazon\.(com|co\.uk|co\.jp|de|fr|it|es|ca|com\.au|in)$/.test(host)) return "amazon";
    if (
      host === "aliexpress.com" || host.endsWith(".aliexpress.com") ||
      host === "aliexpress.us" || host.endsWith(".aliexpress.us")
    ) return "aliexpress";
  } catch (e) {}
  return null;
}

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

document.getElementById("scrape").addEventListener("click", async () => {
  const status = document.getElementById("status");
  status.textContent = "正在抓取…";

  try {
    const tab = await activeTab();
    const platform = platformFromUrl(tab.url);
    if (!platform) {
      status.textContent = "当前页面不是亚马逊或速卖通。请先打开商品/评论页。";
      return;
    }

    const res = await chrome.tabs.sendMessage(tab.id, { type: "SCRAPE", platform });

    if (!res || res.count === 0) {
      status.textContent =
        "❌ 没抓到评论。" +
        (platform === "aliexpress"
          ? "请确认当前是速卖通商品页,并稍等页面加载完成。"
          : "请确认当前是亚马逊评论页(网址含 product-reviews),并先往下滚动加载评论。");
      return;
    }

    const csv = toCSV(res.reviews, res.meta);
    download(csv, `${platform}-reviews-${Date.now()}.csv`);
    status.textContent = `✅ 已导出 ${res.count} 条评论`;
  } catch (e) {
    status.textContent = "抓取失败:" + e.message + "。请刷新页面后重试。";
  }
});

// 诊断按钮:返回当前页面的选择器命中情况,用于真机调试
document.getElementById("diag").addEventListener("click", async () => {
  const status = document.getElementById("status");
  try {
    const tab = await activeTab();
    const res = await chrome.tabs.sendMessage(tab.id, { type: "DIAGNOSE" });
    status.textContent = "诊断信息:\n" + JSON.stringify(res, null, 2);
  } catch (e) {
    status.textContent = "诊断失败:" + e.message + "(可能不在支持的页面上)";
  }
});

function toCSV(reviews, meta) {
  const header = "rating,title,review,date";
  const lines = reviews.map((r) =>
    [r.rating, r.title, r.review, r.date]
      .map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`)
      .join(",")
  );
  // 星级分布元数据(第一行,以 # 开头,供选品工具识别)
  let metaLine = "";
  if (meta) {
    const distStr = (meta.dist || []).map((d) => `${d.star}星=${d.pct}`).join(" ");
    metaLine = `# 平均分=${meta.avg} 总评数=${meta.total} ${distStr}\n`;
  }
  // ﻿ 是 UTF-8 BOM,让 Excel 正确识别中文
  return "﻿" + metaLine + [header, ...lines].join("\n");
}

function download(csv, filename) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
