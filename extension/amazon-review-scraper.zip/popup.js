document.getElementById("scrape").addEventListener("click", async () => {
  const status = document.getElementById("status");
  status.textContent = "正在抓取…";

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const res = await chrome.tabs.sendMessage(tab.id, { type: "SCRAPE" });

    if (!res || res.count === 0) {
      status.textContent = "❌ 没抓到评论。请确认当前是评论页(网址含 product-reviews),并先往下滚动加载评论。";
      return;
    }

    const csv = toCSV(res.reviews, res.meta);
    download(csv, `amazon-reviews-${Date.now()}.csv`);
    status.textContent = `✅ 已导出 ${res.count} 条评论`;
  } catch (e) {
    status.textContent = "抓取失败:" + e.message + "。请刷新评论页后重试。";
  }
});

function toCSV(reviews, meta) {
  const header = "rating,title,review,date";
  const lines = reviews.map((r) =>
    [r.rating, r.title, r.review, r.date]
      .map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`)
      .join(",")
  );
  // 星级分布元数据(第一行,以 # 开头,供选品工具识别)
  let metaLine = "";
  if (meta) {
    const distStr = meta.dist.map((d) => `${d.star}星=${d.pct}`).join(" ");
    metaLine = `# 平均分=${meta.avg} 总评数=${meta.total} ${distStr}\n`;
  }
  // ﻿ 是 UTF-8 BOM,让 Excel 正确识别中文
  return "﻿" + metaLine + [header, ...lines].join("\n");
}

function download(csv, filename) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
