// 跨境电商评论抓取:亚马逊 + 速卖通
// 亚马逊:DOM 解析(抓当前已加载的评论,懒加载的话先往下滚动几屏)
// 速卖通:优先走 feedback JSON 接口(更稳定),失败时兜底 DOM 解析

// ---------- 平台识别 ----------
function detectPlatform() {
  const host = location.hostname.toLowerCase();
  if (/amazon\.(com|co\.uk|co\.jp|de|fr|it|es|ca|com\.au|in)$/.test(host)) return "amazon";
  if (
    host === "aliexpress.com" || host.endsWith(".aliexpress.com") ||
    host === "aliexpress.us" || host.endsWith(".aliexpress.us")
  ) return "aliexpress";
  return null;
}

// ==================== 亚马逊 ====================
function parseRating(el) {
  // 从评分元素提取数字,如 "5.0 out of 5 stars" / "5.0 颗星" -> 5.0
  const alt = el.querySelector(".a-icon-alt");
  const text = alt ? alt.textContent : el.textContent;
  const m = text.match(/(\d+(?:\.\d+)?)/);
  return m ? parseFloat(m[1]) : "";
}

function scrapeRatingDistribution() {
  // 抓取评论页顶部的官方星级分布(平均分 / 总评数 / 各星级百分比)
  const meta = { avg: "", total: "", dist: [] };

  const ratingEl = document.querySelector('[data-hook="rating-out-of-text"]');
  if (ratingEl) {
    const m = ratingEl.textContent.match(/(\d+(?:\.\d+)?)/);
    meta.avg = m ? m[1] : "";
  }

  const countEl = document.querySelector('[data-hook="total-review-count"]');
  if (countEl) {
    const m = countEl.textContent.match(/[\d,]+/);
    meta.total = m ? m[0].replace(/,/g, "") : "";
  }

  document.querySelectorAll(".histogram-row-container").forEach((row) => {
    const pct = row.querySelector(".histogram-column-space")?.textContent?.trim() || "";
    const text = row.textContent.replace(/\s+/g, " ");
    const starMatch = text.match(/([1-5])\s*(?:星|star)/i);
    if (starMatch && pct) {
      meta.dist.push({ star: starMatch[1], pct });
    }
  });

  return meta;
}

function scrapeReviewsAmazon() {
  const reviews = [];
  const reviewNodes = document.querySelectorAll('[data-hook="review"]');

  reviewNodes.forEach((node) => {
    const ratingEl = node.querySelector('[data-hook="review-star-rating"]');
    const titleEl = node.querySelector('[data-hook="review-title"]');
    const bodyEl = node.querySelector('[data-hook="review-body"]');
    const dateEl = node.querySelector('[data-hook="review-date"]');

    const rating = ratingEl ? parseRating(ratingEl) : "";
    const title = titleEl ? titleEl.textContent.trim() : "";
    const body = bodyEl ? bodyEl.textContent.trim() : "";
    const date = dateEl ? dateEl.textContent.trim() : "";

    if (body) {
      reviews.push({ rating, title, review: body, date });
    }
  });

  return reviews;
}

// ==================== 速卖通 ====================
function extractAliexpressProductId() {
  // 商品页 URL 形如 https://www.aliexpress.com/item/1005001234567890.html
  const m = location.pathname.match(/\/(\d{7,})(?:\.html)?/);
  return m ? m[1] : "";
}

function aliRating(raw) {
  // buyerEval 是 0~100 的百分制评分,换算成 5 星制;若已是 5 星制则直接用
  const n = Number(raw);
  if (Number.isNaN(n)) return "";
  return n > 5 ? (n / 20).toFixed(1) : String(n);
}

async function fetchAliexpressReviewsApi() {
  const productId = extractAliexpressProductId();
  if (!productId) return null;

  const url =
    "https://feedback.aliexpress.com/pc/searchEvaluation.do" +
    `?productId=${productId}&lang=en_US&country=US&pageSize=100&filter=all&sort=complex_default`;

  const resp = await fetch(url, { credentials: "include" });
  if (!resp.ok) return null;

  const json = await resp.json();
  const list = (json && json.data && json.data.evaViewList) || [];
  const reviews = list
    .map((e) => ({
      rating: aliRating(e.buyerEval),
      title: "",
      review: String(e.buyerFeedback || e.buyerTranslationFeedback || "").trim(),
      date: e.evalDate || "",
    }))
    .filter((r) => r.review);

  const d = json && json.data ? json.data : {};
  const meta = {
    avg: d.averageStar ?? d.average ?? "",
    total: d.totalNum ?? d.total ?? "",
    dist: [],
  };

  return { count: reviews.length, reviews, meta };
}

// 兜底:DOM 解析(速卖通页面结构常变,接口失败时尽力而为)
function scrapeReviewsAliDom() {
  const reviews = [];
  document
    .querySelectorAll(".feedback-item, [class*='feedback-item'], [class*='review-item']")
    .forEach((node) => {
      const body =
        node.querySelector(".buyer-feedback, [class*='buyer-feedback']") || node;
      const text = body.textContent.trim();
      if (text) reviews.push({ rating: "", title: "", review: text, date: "" });
    });
  return reviews;
}

function scrapeAliMetaDom() {
  return { avg: "", total: "", dist: [] };
}

// ---------- 诊断(真机调选择器用) ----------
function diagnose() {
  const platform = detectPlatform();
  const info = {
    platform,
    url: location.href,
    title: document.title,
    productId: "",
    selectors: {},
  };
  if (platform === "aliexpress") {
    info.productId = extractAliexpressProductId();
    [
      ".feedback-item",
      ".buyer-feedback",
      "[class*='feedback']",
      "[class*='review']",
      "[class*='evaluation']",
    ].forEach((sel) => {
      info.selectors[sel] = document.querySelectorAll(sel).length;
    });
  }
  return info;
}

// ---------- 消息处理 ----------
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "SCRAPE") {
    handleScrape(msg.platform)
      .then((result) => sendResponse(result))
      .catch((e) =>
        sendResponse({ count: 0, reviews: [], meta: {}, error: String((e && e.message) || e) })
      );
    return true; // 异步响应
  }
  if (msg.type === "DIAGNOSE") {
    sendResponse(diagnose());
    return false;
  }
  return true;
});

async function handleScrape(platform) {
  platform = platform || detectPlatform();

  if (platform === "aliexpress") {
    const api = await fetchAliexpressReviewsApi();
    if (api && api.count > 0) return api;
    const reviews = scrapeReviewsAliDom();
    return { count: reviews.length, reviews, meta: scrapeAliMetaDom() };
  }

  const reviews = scrapeReviewsAmazon();
  const meta = scrapeRatingDistribution();
  return { count: reviews.length, reviews, meta };
}
