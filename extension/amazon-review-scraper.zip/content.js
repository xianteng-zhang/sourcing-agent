// 亚马逊评论抓取:解析当前评论页的评论
// 只抓当前 DOM 里已经加载出来的评论(懒加载的话,抓取前先往下滚动几屏)

function parseRating(el) {
  // 从评分元素提取数字,如 "5.0 out of 5 stars" / "5.0 颗星" -> 5.0
  const alt = el.querySelector(".a-icon-alt");
  const text = alt ? alt.textContent : el.textContent;
  const m = text.match(/(\d+(?:\.\d+)?)/);
  return m ? parseFloat(m[1]) : "";
}

function scrapeRatingDistribution() {
  // 抓取评论页顶部的官方星级分布(平均分 / 总评数 / 各星级百分比)
  const meta = { avg: "", total: "", dist: [] };

  const ratingEl = document.querySelector('[data-hook="rating-out-of-text"]');
  if (ratingEl) {
    const m = ratingEl.textContent.match(/(\d+(?:\.\d+)?)/);
    meta.avg = m ? m[1] : "";
  }

  const countEl = document.querySelector('[data-hook="total-review-count"]');
  if (countEl) {
    const m = countEl.textContent.match(/[\d,]+/);
    meta.total = m ? m[0].replace(/,/g, "") : "";
  }

  document.querySelectorAll(".histogram-row-container").forEach((row) => {
    const pct = row.querySelector(".histogram-column-space")?.textContent?.trim() || "";
    const text = row.textContent.replace(/\s+/g, " ");
    const starMatch = text.match(/([1-5])\s*(?:星|star)/i);
    if (starMatch && pct) {
      meta.dist.push({ star: starMatch[1], pct });
    }
  });

  return meta;
}

function scrapeReviews() {
  const reviews = [];
  const reviewNodes = document.querySelectorAll('[data-hook="review"]');

  reviewNodes.forEach((node) => {
    const ratingEl = node.querySelector('[data-hook="review-star-rating"]');
    const titleEl = node.querySelector('[data-hook="review-title"]');
    const bodyEl = node.querySelector('[data-hook="review-body"]');
    const dateEl = node.querySelector('[data-hook="review-date"]');

    const rating = ratingEl ? parseRating(ratingEl) : "";
    const title = titleEl ? titleEl.textContent.trim() : "";
    const body = bodyEl ? bodyEl.textContent.trim() : "";
    const date = dateEl ? dateEl.textContent.trim() : "";

    if (body) {
      reviews.push({ rating, title, review: body, date });
    }
  });

  return reviews;
}

// 监听 popup 发来的抓取指令
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "SCRAPE") {
    const reviews = scrapeReviews();
    const meta = scrapeRatingDistribution();
    sendResponse({ count: reviews.length, reviews, meta });
  }
  return true; // 异步响应
});
